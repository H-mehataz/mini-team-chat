require('dotenv').config();
const express = require('express');
const http = require('http');
const mongoose = require('mongoose');
const cors = require('cors');
const socketio = require('socket.io');

const authRoutes = require('./routes/auth');
const channelRoutes = require('./routes/channels');
const messageRoutes = require('./routes/messages');
const { authenticateSocket } = require('./utils/socketAuth');

const app = express();
const server = http.createServer(app);
const io = socketio(server, {
  cors: { origin: '*' }
});

const onlineUsers = new Map();

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/channels', channelRoutes);
app.use('/api/messages', messageRoutes);

io.on('connection', (socket) => {
  const user = socket.user;
  console.log('User connected:', user?.username);

  if (user) {
    const sockets = onlineUsers.get(user.id) || new Set();
    sockets.add(socket.id);
    onlineUsers.set(user.id, sockets);
  }

  socket.on('joinChannel', (channelId) => {
    socket.join(channelId);
    io.to(channelId).emit('presence', { onlineUserIds: Array.from(onlineUsers.keys()) });
  });

  socket.on('leaveChannel', (channelId) => {
    socket.leave(channelId);
    io.to(channelId).emit('presence', { onlineUserIds: Array.from(onlineUsers.keys()) });
  });

  socket.on('sendMessage', async (payload) => {
    try {
      const Message = require('./models/Message');

      const msg = new Message({
        channel: payload.channelId,
        sender: user.id,
        text: payload.text,
        timestamp: new Date()
      });

      await msg.save();

      io.to(payload.channelId).emit('newMessage', {
        _id: msg._id,
        channel: payload.channelId,
        sender: { _id: user.id, username: user.username },
        text: msg.text,
        timestamp: msg.timestamp
      });
    } catch (err) {
      console.error(err);
      socket.emit('error', { message: 'Send message failed' });
    }
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', user?.username);

    if (user) {
      const sockets = onlineUsers.get(user.id);
      if (sockets) {
        sockets.delete(socket.id);
        if (sockets.size === 0) onlineUsers.delete(user.id);
        else onlineUsers.set(user.id, sockets);
      }
    }
  });
});

const PORT = process.env.PORT || 5000;
const MONGO = process.env.MONGO_URI || '';

mongoose.connect(MONGO)
  .then(() => {
    console.log('MongoDB Connected!');
    server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch(err => console.error(err));
